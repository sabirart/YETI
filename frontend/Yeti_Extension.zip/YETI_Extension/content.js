// Content script that runs on YouTube pages

let buttonInjected = false;
let currentVideoId = null;
let currentVideoUrl = null;

// 🔥 FIX: Check if extension context is still alive
if (!chrome.runtime?.id) {
  console.warn('Extension context invalidated — stopping.');
  throw new Error('Extension context invalidated');
}

// Extract video ID from URL
function getVideoId() {
  const url = window.location.href;
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
  return match ? match[1] : null;
}

// Get video URL
function getVideoUrl() {
  return window.location.href;
}

// Check if we're on a video page
function isVideoPage() {
  return window.location.pathname.includes('/watch') || 
         window.location.hostname === 'youtu.be';
}

// Create the YETI download button
function createYetiButton() {
  const button = document.createElement('button');
  button.id = 'yeti-download-btn';
  button.className = 'yeti-download-btn';
  button.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7 10 12 15 17 10"/>
      <line x1="12" y1="15" x2="12" y2="3"/>
    </svg>
    YETI Download
  `;
  button.title = 'Download with YETI';
  return button;
}

// Inject button into YouTube player controls
function injectButton() {
  if (buttonInjected) return;
  if (!isVideoPage()) return;

  const videoId = getVideoId();
  if (!videoId) return;

  // Try to find the YouTube player controls container
  const selectors = [
    '.ytp-right-controls',
    '.ytp-chrome-bottom .ytp-right-controls',
    '.html5-video-player .ytp-right-controls',
    '.ytp-chrome-controls .ytp-right-controls'
  ];

  let container = null;
  for (const selector of selectors) {
    container = document.querySelector(selector);
    if (container) break;
  }

  if (!container) {
    // If container not found, try again later
    setTimeout(injectButton, 1000);
    return;
  }

  // Check if button already exists
  if (document.getElementById('yeti-download-btn')) {
    buttonInjected = true;
    return;
  }

  // Create and insert button
  const button = createYetiButton();
  
  // Insert at the beginning of right controls
  container.insertBefore(button, container.firstChild);
  
  buttonInjected = true;
  currentVideoId = videoId;
  currentVideoUrl = getVideoUrl();

  // Add click handler
  button.addEventListener('click', handleDownloadClick);
}

// Handle download button click
async function handleDownloadClick(event) {
  event.stopPropagation();
  
  const button = document.getElementById('yeti-download-btn');
  if (!button) return;

  // 🔥 FIX: Check if extension is still alive before using chrome API
  if (!chrome.runtime?.id) {
    showNotification('Extension reloaded — please refresh YouTube', 'error');
    return;
  }

  // Get quality preference from storage
  const storage = await chrome.storage.local.get(['quality']);
  const quality = storage.quality || '720';
  
  const videoId = getVideoId();
  if (!videoId) {
    showNotification('Could not detect video ID', 'error');
    return;
  }

  // Show loading state
  const originalText = button.innerHTML;
  button.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spinner">
      <path d="M12 2v4M12 22v-4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M22 12h-4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
    Adding...
  `;
  button.disabled = true;

  try {
    const url = getVideoUrl();
    
    // Send to YETI app
    const response = await chrome.runtime.sendMessage({
      type: 'SEND_TO_YETI',
      url: url,
      quality: quality
    });

    if (response.success) {
      showNotification('Added to YETI download queue', 'success');
      
      // Open YETI app if not already open
      if (response.result.method === 'tab') {
        // Tab was opened with the URL
        showNotification('Opening YETI app...', 'info');
      }
    } else {
      throw new Error(response.error || 'Failed to add to queue');
    }
  } catch (error) {
    console.error('Download error:', error);
    showNotification('Failed to add to queue', 'error');
  } finally {
    // Restore button
    button.innerHTML = originalText;
    button.disabled = false;
  }
}

// Show notification on YouTube page
function showNotification(message, type = 'info') {
  const colors = {
    success: '#4CAF50',
    error: '#f44336',
    info: '#2196F3',
    warning: '#FF9800'
  };

  const notification = document.createElement('div');
  notification.className = 'yeti-notification';
  notification.style.cssText = `
    position: fixed;
    bottom: 80px;
    right: 20px;
    background: #1a1a1a;
    color: #fff;
    padding: 12px 20px;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 14px;
    font-weight: 400;
    z-index: 99999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    border-left: 4px solid ${colors[type] || colors.info};
    opacity: 0;
    transform: translateY(10px);
    transition: opacity 0.3s, transform 0.3s;
    pointer-events: none;
    max-width: 360px;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);

  // Trigger animation
  requestAnimationFrame(() => {
    notification.style.opacity = '1';
    notification.style.transform = 'translateY(0)';
  });

  // Remove after delay
  setTimeout(() => {
    notification.style.opacity = '0';
    notification.style.transform = 'translateY(10px)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 300);
  }, 3000);
}

// Observe URL changes (for SPA navigation)
function observeUrlChanges() {
  let lastUrl = window.location.href;
  
  const observer = new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      buttonInjected = false;
      setTimeout(injectButton, 500);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Handle messages from background script
if (chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'GET_VIDEO_URL') {
      sendResponse({ url: getVideoUrl(), videoId: getVideoId() });
    }
  });
}

// Initialize
function init() {
  injectButton();
  observeUrlChanges();
  
  // Also try to inject when YouTube's player loads
  document.addEventListener('yt-navigate-finish', () => {
    buttonInjected = false;
    setTimeout(injectButton, 500);
  });
}

// Wait for DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Also check periodically for YouTube's dynamic content
setInterval(() => {
  if (isVideoPage() && !buttonInjected) {
    injectButton();
  }
}, 3000);