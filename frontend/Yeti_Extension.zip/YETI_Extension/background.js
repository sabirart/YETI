// Background service worker for YETI extension

const YETI_APP_URL = 'http://localhost:3001';
const YETI_API_URL = 'http://localhost:3001/api';

// Check if YETI app is running
async function checkAppRunning() {
  try {
    const response = await fetch(`${YETI_API_URL}/info/test`);
    return response.ok;
  } catch {
    return false;
  }
}

// Open YETI app in new tab
async function openYetiApp() {
  const tabs = await chrome.tabs.query({ url: `${YETI_APP_URL}/*` });
  if (tabs.length > 0) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    return tabs[0];
  } else {
    return await chrome.tabs.create({ url: YETI_APP_URL });
  }
}

// Send URL to YETI app
async function sendUrlToYeti(url, quality = '720') {
  try {
    // Check if YETI app tab already exists
    const tabs = await chrome.tabs.query({ url: `${YETI_APP_URL}/*` });
    
    if (tabs.length > 0) {
      // Tab exists - focus it and reload with URL parameter
      const tabId = tabs[0].id;
      await chrome.tabs.update(tabId, { active: true });
      
      // Reload the existing tab with the URL parameter
      const newUrl = `${YETI_APP_URL}?url=${encodeURIComponent(url)}&quality=${quality}`;
      await chrome.tabs.update(tabId, { url: newUrl });
      
      return { success: true, method: 'reload', tabId: tabId };
    }
    
    // No tab found - open new tab with URL parameter
    const newTab = await chrome.tabs.create({
      url: `${YETI_APP_URL}?url=${encodeURIComponent(url)}&quality=${quality}`
    });
    return { success: true, method: 'tab', tabId: newTab.id };
  } catch (error) {
    console.error('Failed to send URL to YETI:', error);
    // Fallback: open new tab
    const newTab = await chrome.tabs.create({
      url: `${YETI_APP_URL}?url=${encodeURIComponent(url)}&quality=${quality}`
    });
    return { success: true, method: 'tab', tabId: newTab.id };
  }
}

// Get video info from YETI backend
async function getVideoInfo(videoId, quality = '720') {
  try {
    const response = await fetch(`${YETI_API_URL}/info/${videoId}?quality=${quality}`);
    if (!response.ok) throw new Error('Failed to fetch video info');
    return await response.json();
  } catch (error) {
    console.error('Error fetching video info:', error);
    return null;
  }
}

// Download video directly (for one-click download)
async function downloadVideo(videoId, quality = '720') {
  try {
    const response = await fetch(`${YETI_API_URL}/download/${videoId}/${quality}`);
    if (!response.ok) throw new Error('Download failed');
    return response;
  } catch (error) {
    console.error('Download error:', error);
    return null;
  }
}

// Message listener - wrapped in a safe check
if (chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'GET_VIDEO_INFO') {
      getVideoInfo(request.videoId, request.quality)
        .then(info => sendResponse({ success: true, info }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
    }
    
    if (request.type === 'DOWNLOAD_VIDEO') {
      downloadVideo(request.videoId, request.quality)
        .then(response => sendResponse({ success: true, response }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
    }
    
    if (request.type === 'SEND_TO_YETI') {
      sendUrlToYeti(request.url, request.quality)
        .then(result => sendResponse({ success: true, result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
    }
    
    if (request.type === 'CHECK_APP') {
      checkAppRunning()
        .then(running => sendResponse({ running }))
        .catch(() => sendResponse({ running: false }));
      return true;
    }
  });
} else {
  console.warn('chrome.runtime.onMessage not available');
}